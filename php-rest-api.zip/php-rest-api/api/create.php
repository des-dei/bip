<?php
require 'db.php';

$data = json_decode(file_get_contents("php://input"), true);

if (!empty($data['name']) && !empty($data['email']) && !empty($data['age'])) {
    try {
        $sql = "INSERT INTO users (name, email, age) VALUES (:name, :email, :age)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':name' => $data['name'],
            ':email' => $data['email'],
            ':age' => $data['age']
        ]);

        echo json_encode([
            "message" => "User created successfully",
            "user" => [
                "id" => $pdo->lastInsertId(),
                "name" => $data['name'],
                "email" => $data['email'],
                "age" => $data['age']
            ]
        ]);
    } catch (PDOException $e) {
        echo json_encode(["error" => $e->getMessage()]);
    }
} else {
    echo json_encode(["error" => "Invalid input"]);
}
?>
