<?php
require 'db.php';

$data = json_decode(file_get_contents("php://input"));

if (!empty($data->id)) {
    $sql = "DELETE FROM users WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':id' => $data->id]);

    echo json_encode(["message" => "User deleted successfully"]);
} else {
    echo json_encode(["error" => "Invalid input"]);
}
?>
