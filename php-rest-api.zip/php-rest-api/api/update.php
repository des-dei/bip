<?php
require 'db.php';

$data = json_decode(file_get_contents("php://input"));

if (!empty($data->id) && !empty($data->name) && !empty($data->email) && !empty($data->age)) {
    $sql = "UPDATE users SET name = :name, email = :email, age = :age WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':id' => $data->id,
        ':name' => $data->name,
        ':email' => $data->email,
        ':age' => $data->age
    ]);
    
    echo json_encode(["message" => "User updated successfully"]);
} else {
    echo json_encode(["error" => "Invalid input"]);
}
?>
